package com.pzr.chatroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 启动器
 * @author pzr
 *
 */
@SpringBootApplication
public class Lancher {
	  public static void main(String[] args) { 
	        SpringApplication.run(Lancher.class, args); 
	    } 

}
